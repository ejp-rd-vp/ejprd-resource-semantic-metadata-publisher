// https://observablehq.com/@ericprud/shex-validator@517
export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], function(md){return(
md`# ShEx Validator`
)});
  main.variable(observer()).define(["md"], function(md){return(
md`## ShExC`
)});
  main.variable(observer("viewof SchemaText")).define("viewof SchemaText", ["html","ActiveButton","Manifest"], function(html,ActiveButton,Manifest){return(
html`<textarea id="schemaText" rows=10 cols=80">${ActiveButton === null ? "" : Manifest[ActiveButton].schema}</textarea>`
)});
  main.variable(observer("SchemaText")).define("SchemaText", ["Generators", "viewof SchemaText"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], function(md){return(
md`## Turtle`
)});
  main.variable(observer("viewof DataText")).define("viewof DataText", ["html","ActiveButton","Manifest"], function(html,ActiveButton,Manifest){return(
html`<textarea id="dataText" rows=10 cols=80>${ActiveButton === null ? "" : Manifest[ActiveButton].data}</textarea>`
)});
  main.variable(observer("DataText")).define("DataText", ["Generators", "viewof DataText"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], function(md){return(
md`## ShapeMap`
)});
  main.variable(observer("viewof QueryMapText")).define("viewof QueryMapText", ["html","Color","ActiveButton","Manifest"], function(html,Color,ActiveButton,Manifest){return(
html`<textarea id="queryMapText" rows=5 cols=80 style="border: thick solid ${Color}">${ActiveButton === null ? "" : Manifest[ActiveButton].queryMap}</textarea>`
)});
  main.variable(observer("QueryMapText")).define("QueryMapText", ["Generators", "viewof QueryMapText"], (G, _) => G.input(_));
  main.variable(observer()).define(["Res","html"], function(Res,html)
{
  const total = Res.passed + Res.failed
  let fraction = total === 0 ? 777 : Math.round((15 - Res.passed/total*4)*0x100 + (11 + Res.passed/total*4)*0x10 + 11).toString(16)
  return html`<div style="border: thick solid #${fraction}; font-size: 2em; text-align: center"><span class="conformant">${Res.passed + ' passed'}</span> -- <span class="nonconformant">${Res.failed + ' failed'}</span></div>`
}
);
  main.variable(observer()).define(["html","ShapeMap","ShEx"], function(html,ShapeMap,ShEx){return(
html`<ul>
  ${ShapeMap.map((d, idx) => {
    const button = html`<li style="border: thick solid ${d.status === 'conformant' ? '#bfb' : d.status === 'nonconformant' ? '#fbb' : '#dd7'}">${d.node + '@' + (d.shape === ShEx.Validator.start ? 'START' : d.shape)}</li>`
    // button.onclick = () => mutable ActiveButton = idx
    return button
  })}
</ul>`
)});
  main.variable(observer("__tags")).define("__tags", ["html","Manifest","mutable ActiveButton"], function(html,Manifest,$0){return(
html`<div>
  ${Manifest.map((d, idx) => {
    const button = html`<button class="${d.status}">${d.schemaLabel + ' -- ' + d.dataLabel}</button>`
    button.onclick = () => $0.value = idx
    return button
  })}
</div>`
)});
  main.variable(observer("viewof ManifestURL")).define("viewof ManifestURL", ["html"], function(html){return(
html`<input style="width:60em" value="https://rawgit.com/shexSpec/shex.js/wikidata/packages/shex-webapp/examples/manifest.json">`
)});
  main.variable(observer("ManifestURL")).define("ManifestURL", ["Generators", "viewof ManifestURL"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], function(md){return(
md`# Appendix`
)});
  main.variable(observer("d3")).define("d3", ["require"], function(require){return(
require('d3')
)});
  main.variable(observer("ShEx")).define("ShEx", ["require"], function(require){return(
require('https://rawgit.com/shexSpec/shex.js/wikidata/browser/shex-browserify.js')
)});
  main.variable(observer("Schema")).define("Schema", ["ShEx","SchemaText"], function(ShEx,SchemaText)
{
  let s = ShEx.Parser.construct(window.location.href).parse(SchemaText)
  return { meta: {base: s.base, prefixes: s.prefixes}, schema: s }
}
);
  main.variable(observer("Data")).define("Data", ["DataText","ShEx"], function(DataText,ShEx)
{
  debugger
  let m = DataText.match(/^[\s]*Endpoint:[\s]*(https?:\/\/.*?)[\s]*$/i)
  if (m) {
    const db = ShEx.Util.makeQueryDB(m[1])
    return { meta: {base: m[1], prefixes: {}}, db: db, endpoint: m[1] }
  } else {
    const db = ShEx.N3.Store()
    const parser = new ShEx.N3.Parser(window.location.href)
    db.addTriples(parser.parse(DataText))
    return { meta: {base: parser._base, prefixes: parser._prefixes}, db: ShEx.Util.makeN3DB(db) }
  }
}
);
  main.variable(observer("Manifest")).define("Manifest", ["d3","ManifestURL"], function(d3,ManifestURL){return(
d3.json(ManifestURL)
)});
  main.variable(observer("ShapeMap")).define("ShapeMap", ["ShEx","Schema","Data","QueryMapText"], function(ShEx,Schema,Data,QueryMapText)
{
  let smp = ShEx.ShapeMapParser.construct(window.location.href, Schema.meta, Data.meta)
  let sm = smp.parse(QueryMapText)
  let fm = sm.reduce((acc, sm) => {
    let added = typeof sm.node === "string" || "@value" in sm.node
      ? [sm]
      : sm.node.type === 'Extension' && sm.node.language === 'http://www.w3.org/ns/shex#Extensions-sparql'
      ? ShEx.Util.executeQuery(sm.node.lexical, Data.endpoint)
        .map(t => ({ node: t[0], shape: sm.shape, status: 'unknown' }))
      : Data.db.getTriplesByIRI(null, sm.node.predicate, null)
        .map(t => ({ node: t.subject, shape: sm.shape, status: 'unknown' }))
    return acc.concat(added)
  }, [])
  return fm
}
);
  main.variable(observer("Res")).define("Res", ["ShEx","Schema","ShapeMap","Data","mutable Color"], function(ShEx,Schema,ShapeMap,Data,$0)
{
  let v = ShEx.Validator.construct(Schema.schema)
  let acc = { passed: 0, failed: 0}
  let todo = ShapeMap
  if (todo.length)
    setTimeout(next, 100)
  return acc

  function next () {
    let m = todo.pop()
    let ret = v.validate(Data.db, [m])
    m.status = ret.type === 'Failure' ? 'nonconformant' : 'conformant'
    // let color = ret.type === 'Failure' ? '#fbb' : '#bfb'
    if (m.status === 'conformant')
      acc.passed++
    else
      acc.failed++

    if (todo.length)
      setTimeout(next, 100)
    else
      $0.value = ret.failed > ret.passed ? '#fbb' : '#bfb'
  }
}
);
  main.define("initial ActiveButton", function(){return(
null
)});
  main.variable(observer("mutable ActiveButton")).define("mutable ActiveButton", ["Mutable", "initial ActiveButton"], (M, _) => new M(_));
  main.variable(observer("ActiveButton")).define("ActiveButton", ["mutable ActiveButton"], _ => _.generator);
  main.define("initial Color", function(){return(
'#bbb'
)});
  main.variable(observer("mutable Color")).define("mutable Color", ["Mutable", "initial Color"], (M, _) => new M(_));
  main.variable(observer("Color")).define("Color", ["mutable Color"], _ => _.generator);
  main.variable(observer("__styles")).define("__styles", ["html"], function(html){return(
html`<style>
.conformant { background-color: #bfb; }
.nonconformant { background-color: #fbb; }
button {
    font-size: .7em;
    padding: 0em 2ex;
    border-radius: .5em;
    border: thin solid #000;
    cursor: pointer;
    box-shadow: 0.1em 0px 1em rgba(255, 255, 255, 0.9) inset;
    margin: 0em 1em;
}
</style>`
)});
  return main;
}
